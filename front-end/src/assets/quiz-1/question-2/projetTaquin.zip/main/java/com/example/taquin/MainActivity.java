package com.example.taquin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private final Button[] buttons = new Button[9];
    int emptyButtonIndex = 8;

    private void shuffleButtons(int levelShuffle) {
        Random random = new Random();
        int shuffleCount = levelShuffle * 2;

        for (int i = 0; i < shuffleCount; i++) {
            int button1Index = random.nextInt(9);
            int button2Index;

            if (button1Index == 0 || button1Index == 3 || button1Index == 6) {
                button2Index = button1Index + 1;
            } else if (button1Index == 1 || button1Index == 2 || button1Index == 4 || button1Index == 5) {
                button2Index = button1Index + 3;
            } else {
                button2Index = button1Index - 1;
            }

            swapButtons(button1Index, button2Index);
        }
    }

    private void swapButtons(int button1Index, int button2Index) {
        Button button1 = buttons[button1Index];
        Button button2 = buttons[button2Index];

        CharSequence tempText = button1.getText();
        Object tempTag = button1.getTag();

        button1.setText(button2.getText());
        button1.setTag(button2.getTag());

        button2.setText(tempText);
        button2.setTag(tempTag);

        if (button1.getVisibility() == View.VISIBLE && button2.getVisibility() == View.GONE) {
            button1.setVisibility(View.GONE);
            button2.setVisibility(View.VISIBLE);
            emptyButtonIndex = button1Index;
        } else if (button1.getVisibility() == View.GONE && button2.getVisibility() == View.VISIBLE) {
            button1.setVisibility(View.VISIBLE);
            button2.setVisibility(View.GONE);
            emptyButtonIndex = button2Index;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startGameButton = findViewById(R.id.startGameButton);

        startGameButton.setOnClickListener(v -> {
            // Hide the start game button
            startGameButton.setVisibility(View.INVISIBLE);

            // Get the buttons
            buttons[0] = findViewById(R.id.button1);
            buttons[1] = findViewById(R.id.button2);
            buttons[2] = findViewById(R.id.button3);
            buttons[3] = findViewById(R.id.button4);
            buttons[4] = findViewById(R.id.button5);
            buttons[5] = findViewById(R.id.button6);
            buttons[6] = findViewById(R.id.button7);
            buttons[7] = findViewById(R.id.button8);
            buttons[8] = findViewById(R.id.button9);

            // Set the custom OnClickListener for each button
            for (int i = 0; i < buttons.length; i++) {
                buttons[i].setOnClickListener(new ButtonClickListener(i));
            }

            shuffleButtons(10);

            // Enable all buttons
            for (Button button : buttons) {
                button.setEnabled(true);
            }
        });
    }

    private class ButtonClickListener implements View.OnClickListener {
        int buttonIndex;

        ButtonClickListener(int index) {
            buttonIndex = index;
        }

        @Override
        public void onClick(View v) {
            char direction = '0'; // 0 = no direction

            if (buttonIndex % 3 != 2 && buttonIndex + 1 == emptyButtonIndex) {
                direction = '1'; // 1 = right
            } else if (buttonIndex % 3 != 0 && buttonIndex - 1 == emptyButtonIndex) {
                direction = '2'; // 2 = left
            } else if (buttonIndex / 3 != 2 && buttonIndex + 3 == emptyButtonIndex) {
                direction = '3'; // 3 = down
            } else if (buttonIndex / 3 != 0 && buttonIndex - 3 == emptyButtonIndex) {
                direction = '4'; // 4 = up
            }

            if (direction != '0') {
                moveButton(buttons[buttonIndex], direction);
            }
        }

        private void moveButton(final Button button, char direction) {
            // Determine the target button index based on the direction
            int targetButtonIndex = -1;
            Animation animation = null;

            switch (direction) {
                case '1':
                    animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.right);
                    targetButtonIndex = emptyButtonIndex - 1;
                    break;
                case '2':
                    animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.left);
                    targetButtonIndex = emptyButtonIndex + 1;
                    break;
                case '3':
                    animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.down);
                    targetButtonIndex = emptyButtonIndex - 3;
                    break;
                case '4':
                    animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.up);
                    targetButtonIndex = emptyButtonIndex + 3;
                    break;
                default:
                    break;
            }

            if (animation != null) {
                int finalTargetButtonIndex = targetButtonIndex;
                animation.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {
                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        // Swap the text and tag between the clicked button and the empty button
                        CharSequence tempText = button.getText();
                        Object tempTag = button.getTag();

                        button.setText(buttons[emptyButtonIndex].getText());
                        button.setTag(buttons[emptyButtonIndex].getTag());

                        buttons[emptyButtonIndex].setText(tempText);
                        buttons[emptyButtonIndex].setTag(tempTag);

                        // Swap the visibility of the clicked button and the empty button
                        button.setVisibility(View.GONE);
                        buttons[emptyButtonIndex].setVisibility(View.VISIBLE);

                        // Update the emptyButtonIndex
                        emptyButtonIndex = finalTargetButtonIndex;
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {
                    }
                });

                button.startAnimation(animation);
            }
        }
    }
}